# Face Recognition

Face recognition using python and mysql.

---

## Useage

### Environment

Create virtual environment using Anaconda.

```
conda create -n face python=3.x
conda activate face
pip install -r requirements.txt
```

### Environment

```
python main.py
```
